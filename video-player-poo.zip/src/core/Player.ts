import { Playlist } from "./Playlist";
import { Video } from "../models/Video";

/** Player com navegação, modos e histórico. */
export class Player {
  #playlist: Playlist;
  #currentIndex = 0;
  #isPlaying = false;
  #loop = false;
  #shuffle = false;
  #history: Video[] = [];

  constructor(playlist: Playlist) {
    if (!playlist) throw new Error('Playlist inválida.');
    if (playlist.size === 0) throw new Error('Playlist vazia. Adicione vídeos antes de criar o Player.');
    this.#playlist = playlist;
  }

  get loop(): boolean { return this.#loop; }
  get shuffle(): boolean { return this.#shuffle; }
  toggleLoop(): void { this.#loop = !this.#loop; console.log(`🔁 Loop: ${this.#loop ? 'ON' : 'OFF'}`); }
  toggleShuffle(): void { this.#shuffle = !this.#shuffle; console.log(`🔀 Shuffle: ${this.#shuffle ? 'ON' : 'OFF'}`); }

  get isPlaying(): boolean { return this.#isPlaying; }
  get current(): Video {
    const v = this.#playlist.getAt(this.#currentIndex);
    if (!v) throw new Error('Índice atual inválido na playlist.');
    return v;
  }
  get history(): readonly Video[] { return this.#history.slice(); }

  play(): void {
    try {
      const video = this.current;
      // Evita duplicar a entrada no histórico quando só está retomando o mesmo vídeo
      const last = this.#history[this.#history.length - 1];
      if (!last || last.id !== video.id) {
        this.#history.push(video);
      }
      this.#isPlaying = true;
      video.play();
    } catch (err) {
      console.error('Erro em play():', (err as Error).message);
    }
  }

  pause(): void {
    try {
      if (!this.#isPlaying) {
        console.log('Player já está pausado.');
        return;
      }
      this.#isPlaying = false;
      this.current.pause();
    } catch (err) {
      console.error('Erro em pause():', (err as Error).message);
    }
  }

  stop(): void {
    try {
      if (!this.#isPlaying) {
        console.log('Player já está parado.');
      }
      this.#isPlaying = false;
      this.current.stop();
    } catch (err) {
      console.error('Erro em stop():', (err as Error).message);
    }
  }

  next(): void {
    try {
      if (this.#shuffle) {
        const nextIndex = this.randomIndexExcept(this.#currentIndex);
        this.#currentIndex = nextIndex;
      } else {
        if (this.#currentIndex < this.#playlist.size - 1) {
          this.#currentIndex++;
        } else if (this.#loop) {
          this.#currentIndex = 0;
        } else {
          console.log('🚧 Fim da playlist. Use loop para reiniciar.');
          this.stop();
          return;
        }
      }
      this.play();
    } catch (err) {
      console.error('Erro em next():', (err as Error).message);
    }
  }

  previous(): void {
    try {
      if (this.#shuffle) {
        const prevIndex = this.randomIndexExcept(this.#currentIndex);
        this.#currentIndex = prevIndex;
      } else {
        if (this.#currentIndex > 0) {
          this.#currentIndex--;
        } else if (this.#loop) {
          this.#currentIndex = this.#playlist.size - 1;
        } else {
          console.log('🚧 Início da playlist. Use loop para voltar ao fim.');
          this.stop();
          return;
        }
      }
      this.play();
    } catch (err) {
      console.error('Erro em previous():', (err as Error).message);
    }
  }

  select(index: number): void {
    try {
      if (typeof index !== 'number' || isNaN(index)) throw new Error('Índice inválido.');
      if (index < 0 || index >= this.#playlist.size) throw new Error('Índice fora do intervalo da playlist.');
      this.#currentIndex = index;
      console.log(`➡️  Selecionado índice ${index} — ${this.current.title}`);
      this.play();
    } catch (err) {
      console.error('Erro em select():', (err as Error).message);
    }
  }

  private randomIndexExcept(current: number): number {
    if (this.#playlist.size <= 1) return current;
    let idx: number;
    do {
      idx = Math.floor(Math.random() * this.#playlist.size);
    } while (idx === current);
    return idx;
  }
}

import { Video } from "../models/Video";

/** Playlist: gerencia coleção de vídeos com proteções básicas. */
export class Playlist {
  #name: string;
  #videos: Video[] = [];

  constructor(name: string, videos: Video[] = []) {
    this.name = name || 'Minha Playlist';
    // Adiciona usando add para garantir validação de duplicatas
    videos.forEach(v => this.add(v));
  }

  get name(): string { return this.#name; }
  set name(value: string) {
    if (!value || !value.trim()) throw new Error('Nome inválido para playlist.');
    this.#name = value.trim();
  }

  get size(): number { return this.#videos.length; }

  // Retorna cópia para evitar vazamento do array interno
  get videos(): readonly Video[] { return this.#videos.slice(); }

  add(video: Video): void {
    if (!video) throw new Error('Vídeo inválido.');
    if (this.#videos.some(v => v.id === video.id)) {
      throw new Error(`Vídeo com id ${video.id} já existe na playlist.`);
    }
    this.#videos.push(video);
  }

  removeById(id: string): boolean {
    const idx = this.#videos.findIndex(v => v.id === id);
    if (idx >= 0) {
      this.#videos.splice(idx, 1);
      return true;
    }
    return false;
  }

  getAt(index: number): Video | undefined {
    if (index < 0 || index >= this.#videos.length) return undefined;
    return this.#videos[index];
  }
}

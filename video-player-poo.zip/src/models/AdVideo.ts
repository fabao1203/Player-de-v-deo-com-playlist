import { Video } from "./Video";

/** Anúncio — subclasse de Video */
export class AdVideo extends Video {
  #brand: string;
  #unskippable: boolean;

  constructor(id: string, title: string, duration: number, brand: string, unskippable = true) {
    super(id, title, duration);
    if (!brand || !brand.trim()) throw new Error('Marca inválida para AdVideo.');
    this.#brand = brand.trim();
    this.#unskippable = Boolean(unskippable);
  }

  get brand(): string { return this.#brand; }
  get unskippable(): boolean { return this.#unskippable; }

  override play(): void {
    console.log(`📢 Anúncio (${this.brand}) — ${this.unskippable ? 'não pulável' : 'pulável'}`);
    super.play();
  }

  override info(): string {
    return `[AD] ${super.info()} — Marca: ${this.brand}, ${this.unskippable ? 'não pulável' : 'pulável'}`;
  }
}

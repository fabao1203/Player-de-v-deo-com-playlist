import { Video } from "./Video";

/** Live — subclasse de Video */
export class LiveStream extends Video {
  #isLive: boolean = true;

  constructor(id: string, title: string) {
    // Duração 0 por convenção para live (sem duração fixa)
    super(id, title, 0);
  }

  get isLive(): boolean { return this.#isLive; }

  override play(): void {
    console.log(`🔴 Ao vivo — ${this.title} (status: ${this.isLive ? 'ONLINE' : 'OFFLINE'})`);
  }

  override stop(): void {
    if (!this.#isLive) {
      console.log('Live já estava encerrada.');
      return;
    }
    console.log(`🛑 Live encerrada: ${this.title}`);
    this.#isLive = false;
  }

  override info(): string {
    return `Live: ${this.title} — ${this.isLive ? 'em andamento' : 'encerrada'}`;
  }
}

import { Infoable, Playable, Seconds } from "./interfaces";

/**
 * Classe base para vídeos.
 * - Abstração: modela propriedades essenciais do vídeo.
 * - Encapsulamento: campos privados com getters/setters.
 */
export class Video implements Playable, Infoable {
  #id: string;
  #title: string;
  #duration: Seconds;

  constructor(id: string, title: string, duration: Seconds) {
    if (!id || !id.trim()) throw new Error('ID inválido para o vídeo.');
    if (!title || !title.trim()) throw new Error('Título inválido para o vídeo.');
    if (typeof duration !== 'number' || duration < 0) throw new Error('Duração inválida.');

    this.#id = id.trim();
    this.#title = title.trim();
    this.#duration = duration;
  }

  get id(): string { return this.#id; }
  get title(): string { return this.#title; }
  set title(value: string) {
    if (!value || !value.trim()) throw new Error('Título inválido.');
    this.#title = value.trim();
  }
  get duration(): Seconds { return this.#duration; }

  play(): void {
    console.log(`▶️  Reproduzindo: ${this.title} (${this.formatDuration()})`);
  }

  pause(): void {
    console.log(`⏸️  Pausado: ${this.title}`);
  }

  stop(): void {
    console.log(`⏹️  Parado: ${this.title}`);
  }

  info(): string {
    return `Vídeo: ${this.title} — duração ${this.formatDuration()}`;
  }

  protected formatDuration(): string {
    const m = Math.floor(this.#duration / 60);
    const s = this.#duration % 60;
    return `${m}m${s.toString().padStart(2, '0')}s`;
  }
}

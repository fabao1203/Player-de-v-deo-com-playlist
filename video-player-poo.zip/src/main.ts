import { Video } from "./models/Video";
import { AdVideo } from "./models/AdVideo";
import { LiveStream } from "./models/LiveStream";
import { Playlist } from "./core/Playlist";
import { Player } from "./core/Player";

function safeRun() {
  try {
    const v1 = new Video('v1', 'Introdução a TS', 310);
    const v2 = new Video('v2', 'POO na prática', 420);
    const ad = new AdVideo('ad1', 'Oferta relâmpago', 15, 'Acme', true);
    const live = new LiveStream('live1', 'Meetup de Devs');

    const playlist = new Playlist('Estudos TS', [v1, ad, v2, live]);

    const player = new Player(playlist);

    console.log('\n=== Início da simulação ===\n');
    console.log('Playlist:');
    playlist.videos.forEach((v, i) => console.log(`  ${i}. ${v.info()}`));

    player.play();           // toca v1
    player.pause();
    player.play();           // retoma v1
    player.next();           // vai para ad
    player.next();           // vai para v2

    player.toggleShuffle();  // liga shuffle
    player.next();           // aleatório
    player.previous();       // aleatório novamente

    player.toggleLoop();     // liga loop
    player.toggleShuffle();  // desliga shuffle

    // Navegar até o fim e testar loop
    player.select(playlist.size - 1); // seleciona live
    player.next();           // com loop ON, volta ao início
    player.stop();

    console.log('\nHistórico de assistidos:');
    player.history.forEach((v, i) => console.log(`  ${i + 1}) ${v.info()}`));

    console.log('\n=== Fim da simulação ===\n');
  } catch (err) {
    console.error('Erro na simulação:', (err as Error).message);
  }
}

safeRun();

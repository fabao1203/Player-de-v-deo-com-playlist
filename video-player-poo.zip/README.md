# Player de Vídeo com Playlist (TypeScript + POO) - Revisado

Esta versão inclui correções e validações extras para reduzir erros de compilação/executação.

## Como executar

```bash
npm install
npm run dev      # executar com ts-node (recomendado para testes)
# ou
npm run build
npm start
```

## Estrutura
- src/models: Video, AdVideo, LiveStream, interfaces
- src/core: Playlist, Player
- src/main.ts: simulação

## Notas das correções
- Validações de índices e entradas (protege contra índice fora do range e entradas duplicadas).
- Histórico não duplica entrada se apenas retomou um vídeo.
- Métodos defensivos no Player (verificam existência antes de acessar).
- Mensagens de erro mais claras para facilitar debug.